

function AboutUsPage(){
    return (
        <div>
            <h1>AboutUsPage</h1>
            <h1>AboutUsPage</h1>
        </div>
    )
}

export default AboutUsPage;