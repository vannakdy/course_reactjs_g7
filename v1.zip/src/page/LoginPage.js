

function LoginPage(){

    return (
        <div>
            <h1>LoginPage</h1>
            <h1>LoginPage</h1>
            <h1>LoginPage</h1>
            <h1>LoginPage</h1>
            <h1>LoginPage</h1>
        </div>
    )
}

export default LoginPage;